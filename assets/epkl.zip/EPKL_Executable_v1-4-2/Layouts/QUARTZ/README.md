DreymaR's Big Bag Of Keyboard Tricks - EPKL
===========================================
<br>

![QUARTZ help image](./QUARTZ_ISO_EPKL.png)

<br>

The rock solid QUARTZ Perfect Pangram layout
--------------------------------------------
- This layout is based on a [perfect pangram][WikPan]. Therefore, it is a perfect layout!
- Somehow, I felt it's best used with AngleWide hand positions, as seen on the colored image below.
- It should be perfectly suited for typists who want to write about quartz glyph jobs.
- If you want to horse around instead of rocking hard, try the Foalmak layout?
<br>

￣(=⌒ᆺ⌒=)￣
<br>

![QUARTZ help image with finger coloring, ANSI board](./QUARTZ_ANS_EPKL-FShui.png)

[WikPan]: https://en.wikipedia.org/wiki/Pangram (Wikipedia on pangrams)