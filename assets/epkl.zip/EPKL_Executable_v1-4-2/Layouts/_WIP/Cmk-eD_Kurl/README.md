DreymaR's Big Bag Of Keyboard Tricks - EPKL
===========================================
<br>

Colemak-Kurl: The V-K swap for Cmk-DH
-------------------------------------
- The V-K swap is a "bleeding-edge" Cmk mod idea to fix the KN/NK and KL/LK same-finger bigrams.
- Note that its benefits are very poorly documented. Alt-fingering these SFBs works very well too.
- Also, it creates an awkward CK bigram which analyzers may not pick up on as it isn't a SFB.
- The VE bigram also gets worse, and it's 3× as common as VK. These may be alt-fingered, but...
- ...what's the point in the end, in avoiding some awkward bigrams to create others?
- Note that some of the newest analysis tries to include such "LSB" Lateral-Stretch Bigrams.
- For more info, analysis and opinions, see the [EPKL Colemak-Q README][CmQpkl].
<br>

|![EPKL help image for Colemak-KurlAngleWideSym on an ISO board, unshifted state](./Cmk-eD_ANS_KurlAWideSym/state0.png)|
|   :---:   |
|_Colemak-eD_ISO_KurlAWideSym, unshifted state_|

[CmQpkl]: /Layouts/Colemak/Cmk-Qmods/   (EPKL Colemak-Q mods)
